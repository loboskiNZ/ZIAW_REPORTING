const assert = require('assert');
const db = require('../src/config/database');
const cabOrchestrator = require('../src/services/CabReadinessOrchestrator');
const http = require('http');

function postRequest(path, body) {
  return new Promise((resolve, reject) => {
    const opts = {
      hostname: 'localhost',
      port: 8080,
      path,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Dev shim auth
        'X-Actor-Type': 'HUMAN',
        'X-Actor-ID': 'gate_tester'
      }
    };

    const req = http.request(opts, (res) => {
      let data = '';
      res.on('data', (chunk) => (data += chunk));
      res.on('end', () => {
        let parsed = {};
        try {
          parsed = data ? JSON.parse(data) : {};
        } catch (e) {
          parsed = { raw: data };
        }
        resolve({ statusCode: res.statusCode, body: parsed });
      });
    });

    req.on('error', reject);
    req.write(JSON.stringify(body));
    req.end();
  });
}

async function seedPassingChecklistAndValidSnapshot(connection, workspaceId) {
  // Fetch all required definitions for VERIFY_CAB
  const [defs] = await connection.query(
    `SELECT id, ownership_type, rule_kind, rule_spec_json
     FROM stage_checklist_definition
     WHERE pipeline_stage = 'VERIFY_CAB' AND is_active = 1 AND is_required = 1`
  );

  // For AUTO HAS_ARTIFACT rules, create the required artifacts so ChecklistEvaluator will PASS them
  for (const d of defs) {
    if (d.ownership_type === 'AUTO' && d.rule_kind === 'HAS_ARTIFACT') {
      const spec = typeof d.rule_spec_json === 'string' ? JSON.parse(d.rule_spec_json) : d.rule_spec_json;
      const types = spec.artifact_type_in || [];
      const minCount = spec.min_count || 1;

      // Insert minCount artifacts for the first type (or all types if listed)
      // ChecklistEvaluator checks COUNT(*) WHERE type IN (types), so any combination totaling minCount works.
      const useType = types[0] || 'TEST_ARTIFACT';
      for (let i = 0; i < minCount; i++) {
        await connection.query(
          `INSERT INTO artifact (workspace_id, type, title, content_json, created_at)
           VALUES (?, ?, ?, ?, NOW())`,
          [workspaceId, useType, `Test Seed ${useType} ${i + 1}`, JSON.stringify({ seeded_by: 'CabGate.test.js' })]
        );
      }
    }
  }

  // Force PASS for all required definitions (covers MANUAL_CONFIRM and any others)
  for (const d of defs) {
    await connection.query(
      `INSERT INTO workspace_checklist_status (workspace_id, checklist_definition_id, status, last_evaluated_at)
       VALUES (?, ?, 'PASS', NOW())
       ON DUPLICATE KEY UPDATE status='PASS', last_evaluated_at=NOW()`,
      [workspaceId, d.id]
    );
  }

  // Insert a valid snapshot with all required numeric fields
  await connection.query(
    `INSERT INTO workspace_snapshot (
      workspace_id,
      pipeline_stage,
      progress_score,
      risk_score,
      readiness_score,
      confidence_score,
      open_findings_count,
      critical_findings_count,
      open_risks_count,
      accepted_risks_count,
      missing_checklist_count,
      jira_total_count,
      jira_done_count,
      metrics_json,
      snapshot_at,
      is_valid
    ) VALUES (
      ?, 'VERIFY_CAB',
      0, 0, 0, 0,
      0, 0, 0, 0, 0,
      0, 0,
      '{}',
      NOW(),
      1
    )`,
    [workspaceId]
  );
}

async function runTests() {
  console.log('Running CAB Gate Tests...');
  const connection = await db.getConnection();

  try {
    // Clean any prior test workspaces
    await connection.query('DELETE FROM workspace WHERE id IN (4, 5)');
    await connection.query('DELETE FROM workspace_snapshot WHERE workspace_id IN (4, 5)');
    await connection.query('DELETE FROM workspace_checklist_status WHERE workspace_id IN (4, 5)');
    await connection.query('DELETE FROM artifact WHERE workspace_id IN (4, 5)');

    // -----------------------
    // TEST 1: NOT_READY blocks
    // -----------------------
    await connection.query(
      "INSERT INTO workspace (id, name, pipeline_stage, cab_readiness_status, cab_review_state, cab_required_approvals, cab_approval_count) VALUES (4, 'GateWS_NOT_READY', 'VERIFY_CAB', 'NOT_READY', 'NONE', 2, 0)"
    );

    console.log('Test 1: Transition NOT_READY -> Reject');
    const r1 = await postRequest('/api/workspaces/4/governance/transition', {
      to_stage: 'RELEASE',
      rationale: 'Testing Gate'
    });

    assert.strictEqual(r1.statusCode, 409);
    assert.strictEqual(r1.body.error, 'CAB_NOT_READY');

    // ----------------------------------------------------------
    // TEST 2: PENDING_REVIEW is NOT blocked by CAB gate
    // Isolate from Test 1 side-effects by using a new workspace id
    // ----------------------------------------------------------
    await connection.query(
      "INSERT INTO workspace (id, name, pipeline_stage, cab_readiness_status, cab_review_state, cab_required_approvals, cab_approval_count) VALUES (5, 'GateWS_READY', 'VERIFY_CAB', 'NOT_READY', 'NONE', 2, 0)"
    );

    await seedPassingChecklistAndValidSnapshot(connection, 5);

    await cabOrchestrator.recomputeAndPersist(5);

    const [ws5] = await connection.query('SELECT cab_readiness_status FROM workspace WHERE id=5');
    console.log('Persisted CAB readiness after recompute (ws5):', ws5[0].cab_readiness_status);
    assert.strictEqual(ws5[0].cab_readiness_status, 'PENDING_REVIEW');

    console.log('Test 2: Transition PENDING_REVIEW -> Allow (not CAB_NOT_READY)');
    const r2 = await postRequest('/api/workspaces/5/governance/transition', {
      to_stage: 'RELEASE',
      rationale: 'Testing Gate Pass'
    });

    // Transition may still be blocked by other checklist rules/rationale,
    // but it must NOT be blocked by CAB_NOT_READY.
    if (r2.statusCode === 409 && r2.body && r2.body.error === 'CAB_NOT_READY') {
      console.log('Response 2:', r2.statusCode, r2.body);
      assert.fail('Should not be blocked by CAB Gate (CAB_NOT_READY)');
    }

    console.log('Response 2:', r2.statusCode, r2.body);
    console.log('✓ CAB Gate Tests Passed');
  } catch (err) {
    console.error('Test Failed:', err);
    process.exit(1);
  } finally {
    connection.release();
    process.exit(0);
  }
}

runTests();
